import 'dart:convert';

import 'package:boxigo_test_app/models/customer_estimate_flow.dart';
import 'package:boxigo_test_app/models/estimate.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Estimate> _customerEstimateFlows = [];

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final customerEstimateFlow = await _getEstimateFlow();
    _customerEstimateFlows = customerEstimateFlow.estimates ?? [];
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: const Text('Flutter Demo'),
        ),
        body: ListView.separated(
          separatorBuilder: (context, index) => const Divider(),
          itemBuilder: (context, index) {
            final estimate = _customerEstimateFlows.elementAt(index);
            return ListTile(
              isThreeLine: true,
              title: Text('Estimate Id: #${estimate.estimateId}'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 2.0,
                  ),
                  Text.rich(
                    TextSpan(
                      children: [
                        const TextSpan(
                          text: 'Moving From: ',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TextSpan(
                          text: '${estimate.movingFrom}',
                        ),
                        const TextSpan(text: 'days'),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 8.0,
                  ),
                  Text.rich(
                    TextSpan(
                      children: [
                        const TextSpan(
                          text: 'Moving To: ',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TextSpan(
                          text: '${estimate.movingTo}',
                        ),
                        const TextSpan(text: 'days'),
                      ],
                    ),
                  ),
                  Text.rich(
                    TextSpan(
                      children: [
                        const TextSpan(
                          text: 'Moving on: ',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TextSpan(
                          text: '${estimate.movingOn}',
                        ),
                        const TextSpan(text: 'days'),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
          itemCount: _customerEstimateFlows.length,
        ));
  }
}

Future<CustomerEstimateFlow> _getEstimateFlow() async {
  final customerEstimateRequest = Uri.http(_baseUrl, '/sample-data/');

  final customerEstimateResponse = await http.get(customerEstimateRequest);

  if (customerEstimateResponse.statusCode != 200) {
    throw Exception('Failed to load customer estimate flow');
  }

  final customerEstimateJson = jsonDecode(
    customerEstimateResponse.body,
  ) as Map<String, dynamic>;

  if (!customerEstimateJson.containsKey('Customer_Estimate_Flow')) {
    throw Exception('Failed to load customer estimate flow');
  }

  return CustomerEstimateFlow.fromJson(customerEstimateJson);
}

const _baseUrl = 'test.api.boxigo.in';
